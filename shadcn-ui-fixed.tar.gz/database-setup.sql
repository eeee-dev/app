-- Financial Dashboard Database Setup
-- Run this SQL in Supabase SQL Editor

-- 1. Create departments table
CREATE TABLE IF NOT EXISTS app_40611b53f9_departments (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  budget DECIMAL(15,2) DEFAULT 0,
  spent DECIMAL(15,2) DEFAULT 0,
  manager VARCHAR(255),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 2. Create projects table
CREATE TABLE IF NOT EXISTS app_40611b53f9_projects (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  name VARCHAR(255) NOT NULL,
  code VARCHAR(100) UNIQUE NOT NULL,
  department_id UUID REFERENCES app_40611b53f9_departments(id),
  description TEXT,
  budget DECIMAL(15,2),
  start_date DATE,
  end_date DATE,
  status VARCHAR(50) DEFAULT 'active',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 3. Create expenses table (updated with project_id)
CREATE TABLE IF NOT EXISTS app_40611b53f9_expenses (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  department_id UUID REFERENCES app_40611b53f9_departments(id),
  project_id UUID REFERENCES app_40611b53f9_projects(id),
  amount DECIMAL(15,2) NOT NULL,
  description TEXT NOT NULL,
  category VARCHAR(100) NOT NULL,
  date DATE NOT NULL,
  status VARCHAR(50) DEFAULT 'pending',
  receipt_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 4. Create enhanced income table (with client info, project_id, department_id)
CREATE TABLE IF NOT EXISTS app_40611b53f9_income (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  invoice_number VARCHAR(100) NOT NULL,
  client_name VARCHAR(255) NOT NULL,
  client_email VARCHAR(255),
  client_phone VARCHAR(100),
  client_address TEXT,
  department_id UUID REFERENCES app_40611b53f9_departments(id),
  project_id UUID REFERENCES app_40611b53f9_projects(id),
  amount DECIMAL(15,2) NOT NULL,
  date DATE NOT NULL,
  due_date DATE NOT NULL,
  status VARCHAR(50) DEFAULT 'pending',
  description TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 5. Create invoices table
CREATE TABLE IF NOT EXISTS app_40611b53f9_invoices (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  invoice_number VARCHAR(100) UNIQUE NOT NULL,
  client_name VARCHAR(255) NOT NULL,
  amount DECIMAL(15,2) NOT NULL,
  date DATE NOT NULL,
  due_date DATE NOT NULL,
  status VARCHAR(50) DEFAULT 'pending',
  items JSONB,
  tax_amount DECIMAL(15,2) DEFAULT 0,
  total_amount DECIMAL(15,2) NOT NULL,
  pdf_url TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 6. Create purchase_orders table
CREATE TABLE IF NOT EXISTS app_40611b53f9_purchase_orders (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  po_number VARCHAR(100) UNIQUE NOT NULL,
  vendor_name VARCHAR(255) NOT NULL,
  amount DECIMAL(15,2) NOT NULL,
  date DATE NOT NULL,
  status VARCHAR(50) DEFAULT 'pending',
  items JSONB,
  department_id UUID REFERENCES app_40611b53f9_departments(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 7. Create bank_statements table
CREATE TABLE IF NOT EXISTS app_40611b53f9_bank_statements (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  bank_name VARCHAR(100) NOT NULL,
  account_number VARCHAR(100),
  statement_date DATE NOT NULL,
  file_url TEXT NOT NULL,
  file_size INTEGER,
  parsed_data JSONB,
  status VARCHAR(50) DEFAULT 'uploaded',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 8. Create transactions table (from bank statements)
CREATE TABLE IF NOT EXISTS app_40611b53f9_transactions (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  bank_statement_id UUID REFERENCES app_40611b53f9_bank_statements(id),
  transaction_date DATE NOT NULL,
  description TEXT NOT NULL,
  amount DECIMAL(15,2) NOT NULL,
  type VARCHAR(50) NOT NULL,
  category VARCHAR(100),
  matched_expense_id UUID REFERENCES app_40611b53f9_expenses(id),
  matched_income_id UUID REFERENCES app_40611b53f9_income(id),
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 9. Create bulk_imports table
CREATE TABLE IF NOT EXISTS app_40611b53f9_bulk_imports (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  file_name VARCHAR(255) NOT NULL,
  file_url TEXT NOT NULL,
  file_type VARCHAR(50) NOT NULL,
  import_type VARCHAR(50) NOT NULL,
  total_records INTEGER DEFAULT 0,
  processed_records INTEGER DEFAULT 0,
  failed_records INTEGER DEFAULT 0,
  status VARCHAR(50) DEFAULT 'processing',
  errors JSONB,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 10. Create audit_trail table
CREATE TABLE IF NOT EXISTS app_40611b53f9_audit_trail (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users,
  action VARCHAR(100) NOT NULL,
  entity_type VARCHAR(100) NOT NULL,
  entity_id UUID,
  details JSONB,
  ip_address VARCHAR(50),
  user_agent TEXT,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL
);

-- 11. Create settings table
CREATE TABLE IF NOT EXISTS app_40611b53f9_settings (
  id UUID DEFAULT gen_random_uuid() PRIMARY KEY,
  user_id UUID REFERENCES auth.users NOT NULL,
  currency VARCHAR(10) DEFAULT 'MUR',
  timezone VARCHAR(50) DEFAULT 'Indian/Mauritius',
  date_format VARCHAR(50) DEFAULT 'DD/MM/YYYY',
  decimal_places INTEGER DEFAULT 2,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT TIMEZONE('utc'::text, NOW()) NOT NULL,
  UNIQUE(user_id)
);

-- Create indexes for better performance
CREATE INDEX IF NOT EXISTS idx_projects_department_id ON app_40611b53f9_projects(department_id);
CREATE INDEX IF NOT EXISTS idx_projects_status ON app_40611b53f9_projects(status);
CREATE INDEX IF NOT EXISTS idx_expenses_user_id ON app_40611b53f9_expenses(user_id);
CREATE INDEX IF NOT EXISTS idx_expenses_department_id ON app_40611b53f9_expenses(department_id);
CREATE INDEX IF NOT EXISTS idx_expenses_project_id ON app_40611b53f9_expenses(project_id);
CREATE INDEX IF NOT EXISTS idx_expenses_date ON app_40611b53f9_expenses(date);
CREATE INDEX IF NOT EXISTS idx_income_user_id ON app_40611b53f9_income(user_id);
CREATE INDEX IF NOT EXISTS idx_income_department_id ON app_40611b53f9_income(department_id);
CREATE INDEX IF NOT EXISTS idx_income_project_id ON app_40611b53f9_income(project_id);
CREATE INDEX IF NOT EXISTS idx_income_date ON app_40611b53f9_income(date);
CREATE INDEX IF NOT EXISTS idx_income_status ON app_40611b53f9_income(status);
CREATE INDEX IF NOT EXISTS idx_invoices_user_id ON app_40611b53f9_invoices(user_id);
CREATE INDEX IF NOT EXISTS idx_invoices_status ON app_40611b53f9_invoices(status);
CREATE INDEX IF NOT EXISTS idx_bank_statements_user_id ON app_40611b53f9_bank_statements(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_user_id ON app_40611b53f9_transactions(user_id);
CREATE INDEX IF NOT EXISTS idx_transactions_bank_statement_id ON app_40611b53f9_transactions(bank_statement_id);
CREATE INDEX IF NOT EXISTS idx_audit_trail_user_id ON app_40611b53f9_audit_trail(user_id);
CREATE INDEX IF NOT EXISTS idx_audit_trail_created_at ON app_40611b53f9_audit_trail(created_at DESC);

-- Setup Row Level Security (RLS)
ALTER TABLE app_40611b53f9_departments ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_40611b53f9_projects ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_40611b53f9_expenses ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_40611b53f9_income ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_40611b53f9_invoices ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_40611b53f9_purchase_orders ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_40611b53f9_bank_statements ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_40611b53f9_transactions ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_40611b53f9_bulk_imports ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_40611b53f9_audit_trail ENABLE ROW LEVEL SECURITY;
ALTER TABLE app_40611b53f9_settings ENABLE ROW LEVEL SECURITY;

-- RLS Policies for departments (admin can read all, users can read)
CREATE POLICY "allow_read_all_departments" ON app_40611b53f9_departments FOR SELECT USING (true);
CREATE POLICY "allow_insert_departments_admin" ON app_40611b53f9_departments FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "allow_update_departments_admin" ON app_40611b53f9_departments FOR UPDATE TO authenticated USING (true);
CREATE POLICY "allow_delete_departments_admin" ON app_40611b53f9_departments FOR DELETE TO authenticated USING (true);

-- RLS Policies for projects (users can read all, admin can manage)
CREATE POLICY "allow_read_all_projects" ON app_40611b53f9_projects FOR SELECT USING (true);
CREATE POLICY "allow_insert_projects_admin" ON app_40611b53f9_projects FOR INSERT TO authenticated WITH CHECK (true);
CREATE POLICY "allow_update_projects_admin" ON app_40611b53f9_projects FOR UPDATE TO authenticated USING (true);
CREATE POLICY "allow_delete_projects_admin" ON app_40611b53f9_projects FOR DELETE TO authenticated USING (true);

-- RLS Policies for expenses (users can only access their own)
CREATE POLICY "allow_read_own_expenses" ON app_40611b53f9_expenses FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "allow_insert_own_expenses" ON app_40611b53f9_expenses FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "allow_update_own_expenses" ON app_40611b53f9_expenses FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "allow_delete_own_expenses" ON app_40611b53f9_expenses FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for income (users can only access their own)
CREATE POLICY "allow_read_own_income" ON app_40611b53f9_income FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "allow_insert_own_income" ON app_40611b53f9_income FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "allow_update_own_income" ON app_40611b53f9_income FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "allow_delete_own_income" ON app_40611b53f9_income FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for invoices (users can only access their own)
CREATE POLICY "allow_read_own_invoices" ON app_40611b53f9_invoices FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "allow_insert_own_invoices" ON app_40611b53f9_invoices FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "allow_update_own_invoices" ON app_40611b53f9_invoices FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "allow_delete_own_invoices" ON app_40611b53f9_invoices FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for purchase_orders (users can only access their own)
CREATE POLICY "allow_read_own_purchase_orders" ON app_40611b53f9_purchase_orders FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "allow_insert_own_purchase_orders" ON app_40611b53f9_purchase_orders FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "allow_update_own_purchase_orders" ON app_40611b53f9_purchase_orders FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "allow_delete_own_purchase_orders" ON app_40611b53f9_purchase_orders FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for bank_statements (users can only access their own)
CREATE POLICY "allow_read_own_bank_statements" ON app_40611b53f9_bank_statements FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "allow_insert_own_bank_statements" ON app_40611b53f9_bank_statements FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "allow_update_own_bank_statements" ON app_40611b53f9_bank_statements FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "allow_delete_own_bank_statements" ON app_40611b53f9_bank_statements FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for transactions (users can only access their own)
CREATE POLICY "allow_read_own_transactions" ON app_40611b53f9_transactions FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "allow_insert_own_transactions" ON app_40611b53f9_transactions FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "allow_update_own_transactions" ON app_40611b53f9_transactions FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "allow_delete_own_transactions" ON app_40611b53f9_transactions FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for bulk_imports (users can only access their own)
CREATE POLICY "allow_read_own_bulk_imports" ON app_40611b53f9_bulk_imports FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "allow_insert_own_bulk_imports" ON app_40611b53f9_bulk_imports FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "allow_update_own_bulk_imports" ON app_40611b53f9_bulk_imports FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "allow_delete_own_bulk_imports" ON app_40611b53f9_bulk_imports FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- RLS Policies for audit_trail (admin can read all, users can read their own)
CREATE POLICY "allow_read_own_audit_trail" ON app_40611b53f9_audit_trail FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "allow_insert_audit_trail" ON app_40611b53f9_audit_trail FOR INSERT TO authenticated WITH CHECK (true);

-- RLS Policies for settings (users can only access their own)
CREATE POLICY "allow_read_own_settings" ON app_40611b53f9_settings FOR SELECT USING (auth.uid() = user_id);
CREATE POLICY "allow_insert_own_settings" ON app_40611b53f9_settings FOR INSERT TO authenticated WITH CHECK (auth.uid() = user_id);
CREATE POLICY "allow_update_own_settings" ON app_40611b53f9_settings FOR UPDATE TO authenticated USING (auth.uid() = user_id);
CREATE POLICY "allow_delete_own_settings" ON app_40611b53f9_settings FOR DELETE TO authenticated USING (auth.uid() = user_id);

-- Create storage bucket for receipts and invoices
INSERT INTO storage.buckets (id, name, public) 
VALUES ('receipts', 'receipts', true) 
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public) 
VALUES ('invoices', 'invoices', true) 
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public) 
VALUES ('bank_statements', 'bank_statements', true) 
ON CONFLICT (id) DO NOTHING;

INSERT INTO storage.buckets (id, name, public) 
VALUES ('imports', 'imports', true) 
ON CONFLICT (id) DO NOTHING;

-- Setup Row Level Security (RLS) for storage
CREATE POLICY "allow_public_read_receipts" ON storage.objects FOR SELECT TO public USING (bucket_id = 'receipts');
CREATE POLICY "allow_users_upload_own_receipts" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'receipts' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "allow_public_read_invoices" ON storage.objects FOR SELECT TO public USING (bucket_id = 'invoices');
CREATE POLICY "allow_users_upload_own_invoices" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'invoices' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "allow_public_read_bank_statements" ON storage.objects FOR SELECT TO public USING (bucket_id = 'bank_statements');
CREATE POLICY "allow_users_upload_own_bank_statements" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'bank_statements' AND (storage.foldername(name))[1] = auth.uid()::text);

CREATE POLICY "allow_public_read_imports" ON storage.objects FOR SELECT TO public USING (bucket_id = 'imports');
CREATE POLICY "allow_users_upload_own_imports" ON storage.objects FOR INSERT TO authenticated WITH CHECK (bucket_id = 'imports' AND (storage.foldername(name))[1] = auth.uid()::text);

-- Insert sample data for testing
INSERT INTO app_40611b53f9_departments (name, budget, spent, manager) VALUES
('musiquë', 500000, 320000, 'John Doe'),
('zimazë', 450000, 280000, 'Jane Smith'),
('bōucan', 600000, 420000, 'Bob Johnson'),
('talënt', 400000, 250000, 'Alice Brown'),
('mōris', 350000, 180000, 'Charlie Wilson')
ON CONFLICT DO NOTHING;

-- Insert sample projects
INSERT INTO app_40611b53f9_projects (name, code, department_id, description, budget, start_date, end_date, status) VALUES
('Music Album Production', 'MAP-2024-001', (SELECT id FROM app_40611b53f9_departments WHERE name = 'musiquë'), 'Production of new music album', 150000, '2024-01-01', '2024-12-31', 'active'),
('Video Marketing Campaign', 'VMC-2024-002', (SELECT id FROM app_40611b53f9_departments WHERE name = 'zimazë'), 'Video marketing campaign for Q4', 120000, '2024-07-01', '2024-12-31', 'active'),
('Studio Equipment Upgrade', 'SEU-2024-003', (SELECT id FROM app_40611b53f9_departments WHERE name = 'bōucan'), 'Upgrade studio recording equipment', 80000, '2024-03-01', '2024-09-30', 'active'),
('Talent Recruitment Drive', 'TRD-2024-004', (SELECT id FROM app_40611b53f9_departments WHERE name = 'talënt'), 'Q4 talent recruitment campaign', 60000, '2024-10-01', '2024-12-31', 'active'),
('Store Expansion Project', 'SEP-2024-005', (SELECT id FROM app_40611b53f9_departments WHERE name = 'mōris'), 'Physical store expansion project', 200000, '2024-06-01', '2025-06-01', 'active')
ON CONFLICT DO NOTHING;

-- Display success message
SELECT '✅ Database setup completed successfully!' as message;