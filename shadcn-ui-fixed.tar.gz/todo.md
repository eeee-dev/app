# Financial Dashboard - Enhancement Plan

## Design Guidelines

### Design References
- **Current Financial Dashboard**: Maintain existing design system
- **Style**: Professional, clean, data-focused financial interface

### Color Palette
- Primary: #0A0A0A (Deep Black - background)
- Secondary: #1A1A1A (Charcoal - cards/sections)
- Accent: #E63946 (Racing Red - CTAs and highlights)
- Text: #FFFFFF (White), #B0B0B0 (Light Gray - secondary)

### Typography
- Heading1: Plus Jakarta Sans font-weight 700 (48px)
- Heading2: Plus Jakarta Sans font-weight 500 (36px)
- Heading3: Plus Jakarta Sans font-weight 500 (24px)
- Body/Normal: Plus Jakarta Sans font-weight 400 (14px)
- Navigation: Plus Jakarta Sans font-weight 700 (16px)

### Component Styles
- **Buttons**: Consistent with existing dashboard style
- **Forms**: Clean, accessible form controls with proper validation
- **Tables**: Responsive tables with action buttons

---

## Development Tasks

### ✅ 1. Fix Departments Page
- ✓ Make annual budget field optional in department creation form
- ✓ Fix validation error that prevents department creation when budget is 0
- ✓ Update validation logic to allow empty/zero budget

### ✅ 2. Add Projects Management
- ✓ Create Projects page with CRUD operations
- ✓ Projects should be linked to departments via dropdown selection
- ✓ Add ability to create, edit, and delete projects
- ✓ Display projects with their associated departments
- ✓ Add Projects to navigation sidebar
- ✓ Add Projects route to App.tsx

### ✅ 3. Update Expenses Page
- ✓ Add project selection dropdown when adding new expenses
- ✓ Update expense form to include project field
- ✓ Modify expense table to show associated project
- ✓ Update database schema for expense-project relationship
- ✓ **Enhanced**: Added VAT calculation with configurable VAT rate
- ✓ **Enhanced**: Updated to use centralized VAT calculation utilities
- ✓ **Enhanced**: Added VAT rate field and automatic calculation

### ✅ 4. Update Invoices Page
- ✓ Add department classification dropdown for services
- ✓ Update invoice form to include department selection
- ✓ Modify invoice table to show associated department
- ✓ Update database schema for invoice-department relationship
- ✓ **Enhanced**: Added VAT calculation with configurable VAT rate
- ✓ **Enhanced**: Updated to use centralized VAT calculation utilities
- ✓ **Enhanced**: Added VAT rate field and automatic calculation
- ✓ **Enhanced**: Enhanced reports to include VAT breakdown

### ✅ 5. Create Income Page
- ✓ Create new Income page with manual input form
- ✓ Add project and department selection for income classification
- ✓ Include client information fields (name, email, phone, address)
- ✓ Implement CRUD operations for income records
- ✓ Add export functionality
- ✓ Add advanced filtering options
- ✓ Implement status management (pending, received, overdue)
- ✓ Add client contact information display

### ✅ 6. VAT Integration
- ✓ Created VAT calculation utilities in utils.ts
- ✓ Added DEFAULT_VAT_RATE constant (15% for Mauritius)
- ✓ Added calculateVAT, calculateTotalWithVAT functions
- ✓ Added formatVATRate, parseVATRate helper functions
- ✓ Added calculateNetAmount, calculateVATFromTotal functions
- ✓ Updated Invoices page with automatic VAT calculation
- ✓ Updated Expenses page with automatic VAT calculation
- ✓ Added VAT rate configuration field in forms
- ✓ Enhanced reports to show VAT breakdown

###  🔄 7. Fix Notification Click Functionality
- Fix notification click to view elements properly

###  🔄 8. Fix Department Creation Error
- Identify and fix department creation error

###  🔄 9. Fix Expense Department Dropdown
- Fix expense creation dropdown not showing departments

### 🔄 10. Add VAT Exemption Option
- Add yes/no VAT toggle for expense creation
- Some suppliers/businesses are VAT exempted

### 🔄 11. Fix Income Page - Manual Entry
- Add manual income entry with popup dialog
- Improve user experience for adding income

###  🔄 12. Add VAT Section to Invoice Scan
- Add VAT section to invoice scan results in Income page

###  🔄 13. Fix Invoice View Button
- Fix invoice view button functionality
- Display information in popup/modal

###  🔄 14. Fix Purchase Orders Page
- Apply similar improvements as Income page
- Ensure consistency across financial modules

###  🔄 15. Create Budget Planning Page
- Create Budget Planning page
- Implement create budget functionality

###  🔄 16. Update Dashboard
- Remove/hide "Enhanced Export" and "Export Reports"
- Clean up dashboard interface

###  🔄 17. Change Overlay Hover Color
- Change overlay hover color effect on boxes
- Improve visual feedback

### 18. Update Database Schema
- Create projects table with department relationship
- Update expenses table to include project_id foreign key
- Update incomes table to include project_id and department_id foreign keys
- Add client information fields to incomes table
- Implement proper foreign key constraints

## Implementation Order
1. ✅ Fix Departments page
2. ✅ Create Projects page
3. ✅ Update Expenses page
4. ✅ Update Invoices page
5. ✅ Create Income page
6. ✅ Implement VAT Integration
7. Fix Notification Click Functionality
8. Fix Department Creation Error
9. Fix Expense Department Dropdown
10. Add VAT Exemption Option
11. Fix Income Page - Manual Entry
12. Add VAT Section to Invoice Scan
13. Fix Invoice View Button
14. Fix Purchase Orders Page
15. Create Budget Planning Page
16. Update Dashboard
17. Change Overlay Hover Color
18. Update Database schema (when Supabase connection is fixed)