import React from 'react';
import { DollarSign, TrendingUp, AlertCircle, PieChart as PieChartIcon } from 'lucide-react';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Progress } from '@/components/ui/progress';
import { formatCurrencyMUR } from '@/lib/utils';

interface StatsCardsProps {
  stats: {
    totalPendingExpenses: number;
    totalBudgetAllocated: number;
    totalBudgetSpent: number;
    budgetUtilization: number;
  };
}

const StatsCards: React.FC<StatsCardsProps> = ({ stats }) => {
  const cards = [
    {
      title: 'Pending Expenses',
      value: formatCurrencyMUR(stats.totalPendingExpenses),
      icon: DollarSign,
      color: 'text-red-600',
      bgColor: 'bg-red-50',
      description: 'Awaiting approval/payment',
      trend: '+12% from last month',
      trendColor: 'text-red-600'
    },
    {
      title: 'Budget Allocated',
      value: formatCurrencyMUR(stats.totalBudgetAllocated),
      icon: PieChartIcon,
      color: 'text-blue-600',
      bgColor: 'bg-blue-50',
      description: 'Total allocated budget',
      trend: '+5% from last quarter',
      trendColor: 'text-green-600'
    },
    {
      title: 'Budget Spent',
      value: formatCurrencyMUR(stats.totalBudgetSpent),
      icon: TrendingUp,
      color: 'text-green-600',
      bgColor: 'bg-green-50',
      description: 'Total expenses incurred',
      trend: 'On track',
      trendColor: 'text-green-600'
    },
    {
      title: 'Budget Utilization',
      value: `${stats.budgetUtilization.toFixed(1)}%`,
      icon: AlertCircle,
      color: stats.budgetUtilization > 80 ? 'text-orange-600' : 'text-purple-600',
      bgColor: stats.budgetUtilization > 80 ? 'bg-orange-50' : 'bg-purple-50',
      description: 'Budget used vs allocated',
      progress: stats.budgetUtilization,
      progressColor: stats.budgetUtilization > 80 ? 'bg-orange-500' : 'bg-purple-500'
    }
  ];

  return (
    <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-4">
      {cards.map((card) => (
        <Card key={card.title} className="overflow-hidden">
          <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
            <CardTitle className="text-sm font-medium">{card.title}</CardTitle>
            <div className={`p-2 rounded-full ${card.bgColor}`}>
              <card.icon className={`h-4 w-4 ${card.color}`} />
            </div>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{card.value}</div>
            <p className="text-xs text-gray-500 mt-1">{card.description}</p>
            
            {card.progress !== undefined ? (
              <div className="mt-4 space-y-2">
                <div className="flex justify-between text-sm">
                  <span className="text-gray-600">Utilization</span>
                  <span className="font-medium">{card.progress.toFixed(1)}%</span>
                </div>
                <Progress value={card.progress} className={`h-2 ${card.progressColor}`} />
                <p className="text-xs text-gray-500 mt-2">
                  {card.progress > 90 
                    ? 'Budget nearly exhausted' 
                    : card.progress > 70 
                    ? 'Monitor spending closely'
                    : 'Healthy utilization'}
                </p>
              </div>
            ) : (
              <p className={`text-xs font-medium mt-2 ${card.trendColor}`}>
                {card.trend}
              </p>
            )}
          </CardContent>
        </Card>
      ))}
    </div>
  );
};

export default StatsCards;