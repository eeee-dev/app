import React from 'react';
import { NavLink } from 'react-router-dom';
import { 
  LayoutDashboard, 
  DollarSign, 
  PieChart, 
  FileText, 
  Users, 
  Settings,
  Building,
  ChevronLeft,
  ChevronRight,
  TrendingUp,
  File,
  ShoppingCart,
  Receipt,
  Banknote,
  Upload,
  Briefcase,
  ClipboardList,
  FileDown,
  BarChart3
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { ScrollArea } from '@/components/ui/scroll-area';
import { cn } from '@/lib/utils';

interface SidebarProps {
  collapsed: boolean;
  onToggle: () => void;
}

const Sidebar: React.FC<SidebarProps> = ({ collapsed, onToggle }) => {
  const navItems = [
    { icon: LayoutDashboard, label: 'Dashboard', path: '/' },
    { icon: DollarSign, label: 'Expenses', path: '/expenses' },
    { icon: TrendingUp, label: 'Income', path: '/income' },
    { icon: File, label: 'Invoices', path: '/invoices' },
    { icon: ShoppingCart, label: 'Purchase Orders', path: '/purchase-orders' },
    { icon: Banknote, label: 'Bank Statements', path: '/bank-statements' },
    { icon: Upload, label: 'Bulk Import', path: '/bulk-import' },
    { icon: PieChart, label: 'Budgets', path: '/budgets' },
    { icon: Receipt, label: 'Tax Return', path: '/tax-return' },
    { icon: FileText, label: 'Reports', path: '/reports' },
    { icon: BarChart3, label: 'Statistics', path: '/statistics' },
    { icon: ClipboardList, label: 'Audit Trail', path: '/audit-trail' },
    { icon: FileDown, label: 'Export Reports', path: '/export-reports' },
    { icon: Building, label: 'Departments', path: '/departments' },
    { icon: Briefcase, label: 'Projects', path: '/projects' },
    { icon: Settings, label: 'Settings', path: '/settings' },
  ];

  const departments = [
    { id: 'musique', name: 'musiquë', color: 'bg-orange-500' },
    { id: 'zimaze', name: 'zimazë', color: 'bg-orange-400' },
    { id: 'boucan', name: 'bōucan', color: 'bg-orange-300' },
    { id: 'talent', name: 'talënt', color: 'bg-orange-600' },
    { id: 'moris', name: 'mōris', color: 'bg-orange-700' },
  ];

  return (
    <div className={cn(
      "flex flex-col h-full bg-gray-900 border-r border-gray-800 transition-all duration-300",
      collapsed ? "w-16" : "w-64"
    )}>
      {/* Logo and Toggle */}
      <div className="flex items-center justify-between p-4 border-b border-gray-800">
        {!collapsed && (
          <div className="flex flex-col items-start space-y-1">
            <div className="flex items-center space-x-2">
              <div className="w-10 h-10 rounded-full bg-gradient-to-r from-orange-500 to-orange-600 flex items-center justify-center">
                <span className="text-white font-bold text-xl">ë</span>
              </div>
              <div className="flex flex-col">
                <span className="text-white font-semibold">ë Finance</span>
                <span className="text-xs text-gray-400">Dashboard</span>
              </div>
            </div>
          </div>
        )}
        {collapsed && (
          <div className="flex flex-col items-center">
            <div className="w-8 h-8 rounded-full bg-gradient-to-r from-orange-500 to-orange-600 flex items-center justify-center">
              <span className="text-white font-bold text-lg">ë</span>
            </div>
          </div>
        )}
        <Button
          variant="ghost"
          size="icon"
          onClick={onToggle}
          className="text-gray-400 hover:text-white hover:bg-gray-800"
        >
          {collapsed ? <ChevronRight size={20} /> : <ChevronLeft size={20} />}
        </Button>
      </div>

      {/* Main Navigation */}
      <ScrollArea className="flex-1 p-4">
        <div className="space-y-1">
          {navItems.map((item) => (
            <NavLink
              key={item.path}
              to={item.path}
              className={({ isActive }) => cn(
                "flex items-center rounded-lg px-3 py-2 text-sm font-medium transition-colors",
                isActive
                  ? "bg-gray-800 text-white"
                  : "text-gray-400 hover:text-white hover:bg-gray-800",
                collapsed ? "justify-center" : "justify-start"
              )}
            >
              <item.icon className={cn("w-5 h-5", !collapsed && "mr-3")} />
              {!collapsed && <span>{item.label}</span>}
            </NavLink>
          ))}
        </div>

        {/* Departments Section */}
        {!collapsed && (
          <div className="mt-8">
            <h3 className="text-xs font-semibold text-gray-500 uppercase tracking-wider mb-3">
              Departments
            </h3>
            <div className="space-y-1">
              {departments.map((dept) => (
                <button
                  key={dept.id}
                  className="flex items-center w-full rounded-lg px-3 py-2 text-sm text-gray-400 hover:text-white hover:bg-gray-800 transition-colors"
                >
                  <div className={cn("w-2 h-2 rounded-full mr-3", dept.color)} />
                  <span>{dept.name}</span>
                </button>
              ))}
            </div>
          </div>
        )}
      </ScrollArea>

      {/* User Profile */}
      <div className={cn(
        "p-4 border-t border-gray-800",
        collapsed ? "flex justify-center" : ""
      )}>
        {!collapsed ? (
          <div className="flex items-center space-x-3">
            <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center">
              <span className="text-white text-sm font-semibold">JD</span>
            </div>
            <div className="flex-1 min-w-0">
              <p className="text-sm font-medium text-white truncate">John Doe</p>
              <p className="text-xs text-gray-400 truncate">CEO</p>
            </div>
          </div>
        ) : (
          <div className="w-8 h-8 rounded-full bg-gray-700 flex items-center justify-center mx-auto">
            <span className="text-white text-sm font-semibold">JD</span>
          </div>
        )}
      </div>
    </div>
  );
};

export default Sidebar;