import React, { useState, useEffect } from 'react';
import { Plus, Filter, Download, Search, Eye, Edit, Trash2, Mail, CheckCircle, XCircle, Clock, FileText, Building, Briefcase, User, Mail as MailIcon, Phone, MapPin, Users, Calendar, DollarSign } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Input } from '@/components/ui/input';
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from '@/components/ui/table';
import { Badge } from '@/components/ui/badge';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { financialDashboardAPI } from '@/lib/supabase';
import { formatCurrencyMUR } from '@/lib/utils';

interface Income {
  id: string;
  invoice_number: string;
  client_name: string;
  client_email: string;
  client_phone: string;
  client_address: string;
  department_id?: string;
  project_id?: string;
  amount: number;
  date: string;
  due_date: string;
  status: string;
  description: string;
  created_at?: string;
  updated_at?: string;
  departments?: {
    name: string;
    budget: number;
    spent: number;
  };
  projects?: {
    name: string;
    code: string;
  };
}

interface Department {
  id: string;
  name: string;
  budget: number;
  spent: number;
  manager?: string;
  created_at?: string;
  updated_at?: string;
}

interface Project {
  id: string;
  name: string;
  code: string;
  department_id: string;
  department_name: string;
  description: string;
  budget: number;
  spent: number;
  start_date: string;
  end_date: string;
  status: string;
  manager: string;
  team_size: number;
  created_at?: string;
  updated_at?: string;
}

interface NewIncomeForm {
  invoice_number: string;
  client_name: string;
  client_email: string;
  client_phone: string;
  client_address: string;
  department_id: string;
  project_id: string;
  amount: number;
  date: string;
  due_date: string;
  status: string;
  description: string;
}

const IncomePage: React.FC = () => {
  const [incomes, setIncomes] = useState<Income[]>([]);
  const [loading, setLoading] = useState(true);
  const [searchTerm, setSearchTerm] = useState('');
  const [statusFilter, setStatusFilter] = useState<string>('all');
  const [clientFilter, setClientFilter] = useState<string>('all');
  const [departmentFilter, setDepartmentFilter] = useState<string>('all');
  const [projectFilter, setProjectFilter] = useState<string>('all');
  const [departments, setDepartments] = useState<Department[]>([]);
  const [projects, setProjects] = useState<Project[]>([]);
  const [isCreateDialogOpen, setIsCreateDialogOpen] = useState(false);
  const [newIncome, setNewIncome] = useState<NewIncomeForm>({
    invoice_number: `INC-${Date.now().toString().slice(-6)}`,
    client_name: '',
    client_email: '',
    client_phone: '',
    client_address: '',
    department_id: '',
    project_id: '',
    amount: 0,
    date: new Date().toISOString().split('T')[0],
    due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'pending',
    description: ''
  });

  useEffect(() => {
    loadData();
  }, []);

  const loadData = async () => {
    try {
      setLoading(true);
      const [incomesData, departmentsData, projectsData] = await Promise.all([
        financialDashboardAPI.getEnhancedIncomes(),
        financialDashboardAPI.getDepartments(),
        financialDashboardAPI.getProjects()
      ]);
      setIncomes(incomesData as Income[]);
      setDepartments(departmentsData as Department[]);
      setProjects(projectsData as Project[]);
    } catch (error) {
      console.error('Error loading data:', error);
      // Use mock data if API fails
      const mockIncomes: Income[] = [
        {
          id: '1',
          invoice_number: 'INV-2025-001',
          client_name: 'Tech Solutions Inc.',
          client_email: 'contact@techsolutions.com',
          client_phone: '+230 123 4567',
          client_address: '123 Tech Street, Port Louis',
          department_id: 'musique',
          project_id: 'proj-001',
          amount: 12500,
          date: '2025-01-15',
          due_date: '2025-02-15',
          status: 'received',
          description: 'Consulting services for Q1 2025'
        },
        {
          id: '2',
          invoice_number: 'INV-2025-002',
          client_name: 'Global Retail Corp',
          client_email: 'accounts@globalretail.com',
          client_phone: '+230 234 5678',
          client_address: '456 Retail Avenue, Ebene',
          department_id: 'zimaze',
          project_id: 'proj-002',
          amount: 8500,
          date: '2025-01-20',
          due_date: '2025-02-20',
          status: 'pending',
          description: 'Brand design services'
        },
        {
          id: '3',
          invoice_number: 'INV-2025-003',
          client_name: 'Healthcare Partners',
          client_email: 'billing@healthcarepartners.mu',
          client_phone: '+230 345 6789',
          client_address: '789 Medical Plaza, Quatre Bornes',
          department_id: 'boucan',
          project_id: 'proj-003',
          amount: 21000,
          date: '2025-01-10',
          due_date: '2025-02-10',
          status: 'received',
          description: 'Equipment installation and setup'
        },
        {
          id: '4',
          invoice_number: 'INV-2025-004',
          client_name: 'Education Foundation',
          client_email: 'finance@edufoundation.org',
          client_phone: '+230 456 7890',
          client_address: '321 Education Lane, Rose Hill',
          department_id: 'talent',
          project_id: 'proj-004',
          amount: 7500,
          date: '2025-01-25',
          due_date: '2025-02-25',
          status: 'overdue',
          description: 'Talent workshop series'
        },
        {
          id: '5',
          invoice_number: 'INV-2025-005',
          client_name: 'Manufacturing Co.',
          client_email: 'accounts@manufacturingco.mu',
          client_phone: '+230 567 8901',
          client_address: '987 Industrial Zone, Phoenix',
          department_id: 'moris',
          project_id: 'proj-005',
          amount: 15000,
          date: '2025-01-18',
          due_date: '2025-02-18',
          status: 'received',
          description: 'Retail expansion consultation'
        }
      ];
      setIncomes(mockIncomes);
    } finally {
      setLoading(false);
    }
  };

  const filteredIncomes = incomes.filter(income => {
    const matchesSearch = searchTerm === '' || 
      income.client_name.toLowerCase().includes(searchTerm.toLowerCase()) ||
      income.invoice_number.toLowerCase().includes(searchTerm.toLowerCase()) ||
      income.description.toLowerCase().includes(searchTerm.toLowerCase());
    
    const matchesStatus = statusFilter === 'all' || income.status === statusFilter;
    const matchesClient = clientFilter === 'all' || income.client_name === clientFilter;
    const matchesDepartment = departmentFilter === 'all' || income.department_id === departmentFilter;
    const matchesProject = projectFilter === 'all' || income.project_id === projectFilter;
    
    return matchesSearch && matchesStatus && matchesClient && matchesDepartment && matchesProject;
  });

  const getStatusBadge = (status: string) => {
    switch (status) {
      case 'received':
        return <Badge className="bg-green-100 text-green-800 hover:bg-green-100">Received</Badge>;
      case 'pending':
        return <Badge className="bg-yellow-100 text-yellow-800 hover:bg-yellow-100">Pending</Badge>;
      case 'overdue':
        return <Badge className="bg-red-100 text-red-800 hover:bg-red-100">Overdue</Badge>;
      default:
        return <Badge className="border border-gray-300 bg-transparent">{status}</Badge>;
    }
  };

  const handleUpdateStatus = async (id: string, status: string) => {
    try {
      await financialDashboardAPI.updateEnhancedIncomeStatus(id, status);
      await loadData();
    } catch (error) {
      console.error('Error updating income status:', error);
      // Update local state if API fails
      setIncomes(prev => prev.map(income => 
        income.id === id ? { ...income, status } : income
      ));
    }
  };

  const handleSendReminder = async (incomeId: string, clientName: string, clientEmail: string) => {
    try {
      // In a real implementation, this would call an API to send email
      console.log(`Sending reminder for income ${incomeId} to client ${clientName} at ${clientEmail}`);
      alert(`Reminder email would be sent to ${clientName} (${clientEmail}) for income ${incomeId}`);
    } catch (error) {
      console.error('Error sending reminder:', error);
      alert('Error sending reminder. Please try again.');
    }
  };

  const handleDeleteIncome = async (id: string) => {
    if (window.confirm('Are you sure you want to delete this income record?')) {
      try {
        // In a real implementation, this would call an API to delete
        // For now, we'll just update locally
        const updatedIncomes = incomes.filter(income => income.id !== id);
        setIncomes(updatedIncomes);
        console.log(`Income ${id} deleted locally`);
        alert('Income record deleted successfully!');
      } catch (error) {
        console.error('Error deleting income:', error);
        alert('Error deleting income. Please try again.');
      }
    }
  };

  const handleCreateIncome = async () => {
    try {
      // Validate required fields
      if (!newIncome.client_name || !newIncome.amount || newIncome.amount <= 0) {
        alert('Please fill in all required fields with valid values.');
        return;
      }

      // In a real implementation, this would call an API to create income
      // For now, we'll create a local income record
      const newIncomeData: Income = {
        id: `inc-${Date.now()}`,
        invoice_number: newIncome.invoice_number,
        client_name: newIncome.client_name,
        client_email: newIncome.client_email,
        client_phone: newIncome.client_phone,
        client_address: newIncome.client_address,
        department_id: newIncome.department_id || undefined,
        project_id: newIncome.project_id || undefined,
        amount: newIncome.amount,
        date: newIncome.date,
        due_date: newIncome.due_date,
        status: newIncome.status,
        description: newIncome.description,
        created_at: new Date().toISOString(),
        updated_at: new Date().toISOString()
      };

      // Add to local state
      setIncomes([...incomes, newIncomeData]);
      
      // Reset form
      setNewIncome({
        invoice_number: `INC-${Date.now().toString().slice(-6)}`,
        client_name: '',
        client_email: '',
        client_phone: '',
        client_address: '',
        department_id: '',
        project_id: '',
        amount: 0,
        date: new Date().toISOString().split('T')[0],
        due_date: new Date(Date.now() + 30 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
        status: 'pending',
        description: ''
      });

      // Close dialog
      setIsCreateDialogOpen(false);
      
      alert('Income record created successfully!');
    } catch (error) {
      console.error('Error creating income:', error);
      alert('Error creating income. Please try again.');
    }
  };

  const handleInputChange = (field: keyof NewIncomeForm, value: string | number) => {
    setNewIncome(prev => ({
      ...prev,
      [field]: value
    }));
  };

  const handleExportIncomes = () => {
    try {
      // Create CSV content
      const headers = ['Invoice #', 'Client', 'Email', 'Phone', 'Department', 'Project', 'Amount', 'Date', 'Due Date', 'Status', 'Description'];
      const csvContent = [
        headers.join(','),
        ...filteredIncomes.map(income => [
          income.invoice_number,
          `"${income.client_name.replace(/"/g, '""')}"`,
          income.client_email,
          income.client_phone,
          income.department_id ? departments.find(d => d.id === income.department_id)?.name || 'Unknown' : 'Not assigned',
          income.project_id ? projects.find(p => p.id === income.project_id)?.name || 'Unknown Project' : 'Not assigned',
          income.amount,
          income.date,
          income.due_date,
          income.status,
          `"${income.description.replace(/"/g, '""')}"`
        ].join(','))
      ].join('\n');

      // Create blob and download
      const blob = new Blob([csvContent], { type: 'text/csv;charset=utf-8;' });
      const link = document.createElement('a');
      const url = URL.createObjectURL(blob);
      link.setAttribute('href', url);
      link.setAttribute('download', `incomes_${new Date().toISOString().split('T')[0]}.csv`);
      link.style.visibility = 'hidden';
      document.body.appendChild(link);
      link.click();
      document.body.removeChild(link);
      
      alert('Incomes exported successfully!');
    } catch (error) {
      console.error('Error exporting incomes:', error);
      alert('Error exporting incomes. Please try again.');
    }
  };

  const handleFilterIncomes = () => {
    // Open advanced filter panel
    const filterOptions = {
      dateRange: 'last30days',
      amountMin: 0,
      amountMax: 1000000,
      department: departmentFilter === 'all' ? 'all' : departments.find(d => d.id === departmentFilter)?.name || 'all',
      project: projectFilter === 'all' ? 'all' : projects.find(p => p.id === projectFilter)?.name || 'all'
    };
    
    const filterMessage = `Opening advanced filter panel with options:
    - Date Range: ${filterOptions.dateRange}
    - Amount Range: ${formatCurrencyMUR(filterOptions.amountMin)} - ${formatCurrencyMUR(filterOptions.amountMax)}
    - Department: ${filterOptions.department}
    - Project: ${filterOptions.project}`;
    
    alert(filterMessage);
    
    // In a real implementation, this would open a filter dialog
    // For now, we'll apply some sample filters
    setStatusFilter('pending');
    setDepartmentFilter('all');
    setProjectFilter('all');
    alert('Applied filter: Show only pending incomes');
  };

  const totalIncomes = incomes.reduce((sum, income) => sum + income.amount, 0);
  const pendingIncomes = incomes.filter(i => i.status === 'pending').reduce((sum, income) => sum + income.amount, 0);
  const overdueIncomes = incomes.filter(i => i.status === 'overdue').reduce((sum, income) => sum + income.amount, 0);
  const receivedIncomes = incomes.filter(i => i.status === 'received').reduce((sum, income) => sum + income.amount, 0);

  const uniqueClients = Array.from(new Set(incomes.map(inc => inc.client_name)));

  // Get projects filtered by selected department
  const filteredProjects = newIncome.department_id 
    ? projects.filter(project => project.department_id === newIncome.department_id)
    : [];

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-gray-900">Income Management</h1>
          <p className="text-gray-600 mt-1">Track, manage, and classify all income sources with project and department tracking</p>
        </div>
        <div className="flex items-center space-x-3">
          <Button 
            className="gap-2 border border-gray-300 bg-transparent hover:bg-gray-100"
            onClick={handleFilterIncomes}
          >
            <Filter className="h-4 w-4" />
            Filter
          </Button>
          <Button 
            className="gap-2 border border-gray-300 bg-transparent hover:bg-gray-100"
            onClick={handleExportIncomes}
          >
            <Download className="h-4 w-4" />
            Export
          </Button>
          
          <Dialog open={isCreateDialogOpen} onOpenChange={setIsCreateDialogOpen}>
            <DialogTrigger asChild>
              <Button className="gap-2 bg-blue-600 hover:bg-blue-700">
                <Plus className="h-4 w-4" />
                Add Income
              </Button>
            </DialogTrigger>
            <DialogContent className="sm:max-w-[700px] max-h-[90vh] overflow-y-auto">
              <DialogHeader>
                <DialogTitle>Add New Income Record</DialogTitle>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="invoice_number">Invoice Number</Label>
                    <Input
                      id="invoice_number"
                      value={newIncome.invoice_number}
                      onChange={(e) => handleInputChange('invoice_number', e.target.value)}
                      placeholder="INC-001"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount (MUR) *</Label>
                    <Input
                      id="amount"
                      type="number"
                      value={newIncome.amount}
                      onChange={(e) => handleInputChange('amount', parseFloat(e.target.value) || 0)}
                      placeholder="0.00"
                      min="0"
                      step="0.01"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="client_name">Client Name *</Label>
                    <Input
                      id="client_name"
                      value={newIncome.client_name}
                      onChange={(e) => handleInputChange('client_name', e.target.value)}
                      placeholder="Enter client name"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="client_email">Client Email</Label>
                    <Input
                      id="client_email"
                      type="email"
                      value={newIncome.client_email}
                      onChange={(e) => handleInputChange('client_email', e.target.value)}
                      placeholder="client@example.com"
                    />
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="client_phone">Client Phone</Label>
                    <Input
                      id="client_phone"
                      value={newIncome.client_phone}
                      onChange={(e) => handleInputChange('client_phone', e.target.value)}
                      placeholder="+230 123 4567"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="status">Status</Label>
                    <Select value={newIncome.status} onValueChange={(value) => handleInputChange('status', value)}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select status" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pending">Pending</SelectItem>
                        <SelectItem value="received">Received</SelectItem>
                        <SelectItem value="overdue">Overdue</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="client_address">Client Address</Label>
                  <Input
                    id="client_address"
                    value={newIncome.client_address}
                    onChange={(e) => handleInputChange('client_address', e.target.value)}
                    placeholder="Enter client address"
                  />
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="department_id">Department (Optional)</Label>
                    <Select 
                      value={newIncome.department_id} 
                      onValueChange={(value) => {
                        handleInputChange('department_id', value);
                        // Reset project when department changes
                        handleInputChange('project_id', '');
                      }}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder="Select department" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Not assigned to department</SelectItem>
                        {departments.map(dept => (
                          <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="project_id">Project (Optional)</Label>
                    <Select 
                      value={newIncome.project_id} 
                      onValueChange={(value) => handleInputChange('project_id', value)}
                      disabled={!newIncome.department_id}
                    >
                      <SelectTrigger>
                        <SelectValue placeholder={newIncome.department_id ? "Select project" : "Select department first"} />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="all">Not assigned to project</SelectItem>
                        {filteredProjects.map(project => (
                          <SelectItem key={project.id} value={project.id}>
                            {project.code} - {project.name}
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
                
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="date">Income Date</Label>
                    <Input
                      id="date"
                      type="date"
                      value={newIncome.date}
                      onChange={(e) => handleInputChange('date', e.target.value)}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="due_date">Due Date</Label>
                    <Input
                      id="due_date"
                      type="date"
                      value={newIncome.due_date}
                      onChange={(e) => handleInputChange('due_date', e.target.value)}
                    />
                  </div>
                </div>
                
                <div className="space-y-2">
                  <Label htmlFor="description">Description</Label>
                  <Textarea
                    id="description"
                    value={newIncome.description}
                    onChange={(e) => handleInputChange('description', e.target.value)}
                    placeholder="Enter income description or notes..."
                    rows={3}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button variant="outline" onClick={() => setIsCreateDialogOpen(false)}>
                  Cancel
                </Button>
                <Button onClick={handleCreateIncome}>
                  Create Income Record
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Total Income</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{formatCurrencyMUR(totalIncomes)}</div>
            <p className="text-sm text-gray-500 mt-1">{incomes.length} records</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Pending</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-yellow-600">{formatCurrencyMUR(pendingIncomes)}</div>
            <p className="text-sm text-gray-500 mt-1">{incomes.filter(i => i.status === 'pending').length} records</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Overdue</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-red-600">{formatCurrencyMUR(overdueIncomes)}</div>
            <p className="text-sm text-gray-500 mt-1">{incomes.filter(i => i.status === 'overdue').length} records</p>
          </CardContent>
        </Card>
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-gray-600">Received</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold text-green-600">{formatCurrencyMUR(receivedIncomes)}</div>
            <p className="text-sm text-gray-500 mt-1">{incomes.filter(i => i.status === 'received').length} records</p>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
            <CardTitle>All Income Records</CardTitle>
            <div className="flex flex-col md:flex-row gap-3">
              <div className="flex items-center space-x-3">
                <div className="relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400 h-4 w-4" />
                  <Input 
                    placeholder="Search incomes..." 
                    className="w-full md:w-64 pl-10"
                    value={searchTerm}
                    onChange={(e) => setSearchTerm(e.target.value)}
                  />
                </div>
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="All Status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Status</SelectItem>
                    <SelectItem value="pending">Pending</SelectItem>
                    <SelectItem value="received">Received</SelectItem>
                    <SelectItem value="overdue">Overdue</SelectItem>
                  </SelectContent>
                </Select>
                <Select value={clientFilter} onValueChange={setClientFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="All Clients" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Clients</SelectItem>
                    {uniqueClients.map(client => (
                      <SelectItem key={client} value={client}>{client}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={departmentFilter} onValueChange={setDepartmentFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="All Departments" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Departments</SelectItem>
                    {departments.map(dept => (
                      <SelectItem key={dept.id} value={dept.id}>{dept.name}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                <Select value={projectFilter} onValueChange={setProjectFilter}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder="All Projects" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">All Projects</SelectItem>
                    {projects.map(project => (
                      <SelectItem key={project.id} value={project.id}>
                        {project.code} - {project.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
            </div>
          </div>
        </CardHeader>
        <CardContent>
          <Tabs defaultValue="all">
            <TabsList>
              <TabsTrigger value="all">All Incomes</TabsTrigger>
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="overdue">Overdue</TabsTrigger>
              <TabsTrigger value="received">Received</TabsTrigger>
            </TabsList>
            <TabsContent value="all" className="mt-6">
              {loading ? (
                <div className="text-center py-12">
                  <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto"></div>
                  <p className="text-gray-500 mt-4">Loading income records...</p>
                </div>
              ) : filteredIncomes.length === 0 ? (
                <div className="text-center py-12">
                  <div className="text-gray-400 mb-4">No income records found</div>
                  <p className="text-gray-500">Try adjusting your filters or add a new income record</p>
                </div>
              ) : (
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Invoice #</TableHead>
                        <TableHead>Client</TableHead>
                        <TableHead>Contact</TableHead>
                        <TableHead>Department</TableHead>
                        <TableHead>Project</TableHead>
                        <TableHead>Amount</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Due Date</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredIncomes.map((income) => {
                        const isOverdue = income.status === 'overdue' || 
                          (income.status === 'pending' && new Date(income.due_date) < new Date());
                        
                        return (
                          <TableRow key={income.id} className={isOverdue ? 'bg-red-50' : ''}>
                            <TableCell className="font-medium">{income.invoice_number}</TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                <span className="font-medium">{income.client_name}</span>
                                {income.client_email && (
                                  <span className="text-xs text-gray-500">{income.client_email}</span>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              <div className="flex flex-col">
                                {income.client_phone && (
                                  <div className="flex items-center space-x-1">
                                    <Phone className="h-3 w-3 text-gray-500" />
                                    <span className="text-sm">{income.client_phone}</span>
                                  </div>
                                )}
                                {income.client_address && (
                                  <div className="flex items-center space-x-1 mt-1">
                                    <MapPin className="h-3 w-3 text-gray-500" />
                                    <span className="text-xs text-gray-500 truncate max-w-[120px]">{income.client_address}</span>
                                  </div>
                                )}
                              </div>
                            </TableCell>
                            <TableCell>
                              {income.department_id ? (
                                <div className="flex items-center space-x-1">
                                  <Building className="h-3 w-3 text-gray-500" />
                                  <span>{departments.find(d => d.id === income.department_id)?.name || 'Unknown Department'}</span>
                                </div>
                              ) : (
                                <span className="text-gray-400 text-sm">Not assigned</span>
                              )}
                            </TableCell>
                            <TableCell>
                              {income.project_id ? (
                                <div className="flex items-center space-x-1">
                                  <Briefcase className="h-3 w-3 text-gray-500" />
                                  <span>{projects.find(p => p.id === income.project_id)?.name || 'Unknown Project'}</span>
                                </div>
                              ) : (
                                <span className="text-gray-400 text-sm">Not assigned</span>
                              )}
                            </TableCell>
                            <TableCell className="font-medium">{formatCurrencyMUR(income.amount)}</TableCell>
                            <TableCell>{new Date(income.date).toLocaleDateString()}</TableCell>
                            <TableCell className={isOverdue ? 'text-red-600 font-medium' : ''}>
                              {new Date(income.due_date).toLocaleDateString()}
                              {isOverdue && <Clock className="h-3 w-3 inline ml-1" />}
                            </TableCell>
                            <TableCell>{getStatusBadge(income.status)}</TableCell>
                            <TableCell className="text-right">
                              <div className="flex justify-end space-x-2">
                                <Button 
                                  className="h-8 w-8 p-0 border border-gray-300 bg-transparent hover:bg-gray-100"
                                  onClick={() => alert(`Viewing income: ${income.invoice_number}`)}
                                >
                                  <Eye className="h-4 w-4" />
                                </Button>
                                <Button 
                                  className="h-8 w-8 p-0 border border-gray-300 bg-transparent hover:bg-gray-100"
                                  onClick={() => handleSendReminder(income.id, income.client_name, income.client_email)}
                                >
                                  <MailIcon className="h-4 w-4" />
                                </Button>
                                {income.status === 'pending' && (
                                  <Button 
                                    className="h-8 w-8 p-0 border border-gray-300 bg-transparent hover:bg-gray-100 text-green-600 hover:text-green-700"
                                    onClick={() => handleUpdateStatus(income.id, 'received')}
                                  >
                                    <CheckCircle className="h-4 w-4" />
                                  </Button>
                                )}
                                <Button 
                                  className="h-8 w-8 p-0 border border-gray-300 bg-transparent hover:bg-gray-100 text-red-600 hover:text-red-700"
                                  onClick={() => handleDeleteIncome(income.id)}
                                >
                                  <Trash2 className="h-4 w-4" />
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </div>
  );
};

export default IncomePage;